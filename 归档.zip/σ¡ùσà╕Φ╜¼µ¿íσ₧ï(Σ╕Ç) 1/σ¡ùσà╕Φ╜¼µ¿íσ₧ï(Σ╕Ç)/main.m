//
//  main.m
//  字典转模型(一)
//
//  Created by 叶 on 15/9/8.
//  Copyright (c) 2015年 six. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "User.h"
#import "NSObject+Property.h"

#pragma mark --函数声明
void execute(void (*fun)());
void keyValue2object();

#pragma mark --main
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        execute(keyValue2object);
    }
    return 0;
}

void execute(void (*fun)()){
    fun();
    return;
}

#pragma mark --字典转模型
/**
 *  字典转模型(最简单情况)
 */
void keyValue2object(){
    NSDictionary *dict = @{
                           @"name" : @"Jack",
                           @"icon" : @"lufy.png",
                           @"age" : @"20",
                           @"height" : @1.55,
                           @"money" : @"100.9",
                           @"sex" : @(SexFemale),
                           @"gay" : @"1"
                           //                                                      @"gay" : @"NO"
                           //                           @"gay" : @"true",
                           };
    
    NSArray *propertyArray = [User properties];
}

// 3.打印User模型的属性
//    NSLog(@"name=%@, icon=%@, age=%zd, height=%@, money=%@, sex=%d, gay=%d", user.name, user.icon, user.age, user.height, user.money, user.sex, user.gay);

