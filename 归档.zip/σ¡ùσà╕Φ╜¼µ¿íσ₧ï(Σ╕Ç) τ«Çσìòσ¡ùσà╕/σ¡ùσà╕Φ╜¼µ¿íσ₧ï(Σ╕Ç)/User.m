//
//  User.m
//  字典转模型
//
//  Created by 叶 on 15/8/27.
//  Copyright (c) 2015年 six. All rights reserved.
//

#import "User.h"

@interface User ()

@end

@implementation User

@end
