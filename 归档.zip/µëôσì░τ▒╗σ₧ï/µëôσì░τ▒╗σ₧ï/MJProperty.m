//
//  MJProperty.m
//  字典转模型(一)
//
//  Created by 叶 on 15/9/9.
//  Copyright (c) 2015年 six. All rights reserved.
//

#import "MJProperty.h"

@implementation MJProperty

@end
