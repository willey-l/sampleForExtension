//
//  main.m
//  字典转模型(一)
//
//  Created by 叶 on 15/9/8.
//  Copyright (c) 2015年 six. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "User.h"
#import "NSObject+Property.h"
#import "NSObject+keyValue2object.h"
#import "Status.h"

#pragma mark --函数声明
void execute(void (*fun)());
void keyValue2object();
void keyValues2object1();
void keyValues2object2();

#pragma mark --main
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
//        execute(keyValue2object);
//        execute(keyValues2object1);
        execute(keyValues2object2);
    }
    return 0;
}

void execute(void (*fun)()){
    fun();
    return;
}

#pragma mark --字典转模型
/**
 *  字典转模型(最简单情况)
 */
void keyValue2object(){
    NSDictionary *dict = @{
                           @"name" : @"Jack",
                           @"icon" : @"lufy.png",
                           @"age" : @"20",
                           @"height" : @1.55,
                           @"money" : @"100.9",
                           @"sex" : @(SexFemale),
//                           @"gay" : @"1"
//                           @"gay" : @"NO"
                           @"gay" : @"true",
                           };
    User *user = [User objectWithKeyValues:dict];
    
    NSLog(@"name=%@, icon=%@, age=%zd, height=%@, money=%@, sex=%d, gay=%d", user.name, user.icon, user.age, user.height, user.money, user.sex, user.gay);
}

/**
 *  JSON字符串 -> 模型
 */
void keyValues2object1()
{
    // 1.定义一个JSON字符串
    NSString *jsonString = @"{\"name\":\"Jack\", \"icon\":\"lufy.png\", \"age\":20}";
    
    // 2.将JSON字符串转为User模型
    User *user = [User objectWithKeyValues:jsonString];
    
    // 3.打印User模型的属性
    NSLog(@"name=%@, icon=%@, age=%d", user.name, user.icon, user.age);
}

/**
 *  复杂的字典 -> 模型 (模型里面包含了模型)
 */
void keyValues2object2()
{
    // 1.定义一个字典
    NSDictionary *dict = @{
                           @"text" : @"是啊，今天天气确实不错！",
                           
                           @"user" : @{
                                   @"name" : @"Jack",
                                   @"icon" : @"lufy.png"
                                   },
                           
                           @"retweetedStatus" : @{
                                   @"text" : @"今天天气真不错！",
                                   
                                   @"user" : @{
                                           @"name" : @"Rose",
                                           @"icon" : @"nami.png"
                                           }
                                   }
                           };
    
    // 2.将字典转为Status模型
    Status *status = [Status objectWithKeyValues:dict];
    
    // 3.打印status的属性
    NSString *text = status.text;
    NSString *name = status.user.name;
    NSString *icon = status.user.icon;
    NSLog(@"text=%@, name=%@, icon=%@", text, name, icon);
    
    // 4.打印status.retweetedStatus的属性
    NSString *text2 = status.retweetedStatus.text;
    NSString *name2 = status.retweetedStatus.user.name;
    NSString *icon2 = status.retweetedStatus.user.icon;
    NSLog(@"text2=%@, name2=%@, icon2=%@", text2, name2, icon2);
}

