//
//  IDAndDescription.m
//  字典转模型(一)
//
//  Created by 叶 on 15/9/13.
//  Copyright (c) 2015年 six. All rights reserved.
//

#import "IDAndDescription.h"

@implementation IDAndDescription

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"ID" : @"id",
             @"Description" : @"description"
             };
}

@end
