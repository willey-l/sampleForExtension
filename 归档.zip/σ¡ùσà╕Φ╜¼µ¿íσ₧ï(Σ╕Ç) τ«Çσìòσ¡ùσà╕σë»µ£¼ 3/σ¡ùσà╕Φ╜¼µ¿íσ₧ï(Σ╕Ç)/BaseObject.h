//
//  BaseObject.h
//  MJExtensionExample
//
//  Created by MJ Lee on 15/7/18.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseObject : NSObject
@property (copy, nonatomic) NSString *name;
@end
