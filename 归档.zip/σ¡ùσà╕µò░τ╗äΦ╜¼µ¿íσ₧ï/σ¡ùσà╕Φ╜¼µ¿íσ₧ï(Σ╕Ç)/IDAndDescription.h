//
//  IDAndDescription.h
//  字典转模型(一)
//
//  Created by 叶 on 15/9/13.
//  Copyright (c) 2015年 six. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IDAndDescription : NSObject

@property (nonatomic, copy) NSString *ID;
@property (nonatomic, copy) NSString *Description;

@end
