//
//  NSObject+keyValue2object.m
//  字典转模型(一)
//
//  Created by 叶 on 15/9/8.
//  Copyright (c) 2015年 six. All rights reserved.
//

#import "NSObject+keyValue2object.h"
#import "NSObject+Property.h"

@implementation NSObject (keyValue2object)
+ (instancetype)objectWithKeyValues:(id)keyValues{
    if (!keyValues) return nil;
    return [[[self alloc] init] properties];
}
@end
